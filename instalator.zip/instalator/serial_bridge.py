import serial
import struct
import json
from multiprocessing import Process, Pipe
from inverse_kin_delta import inverse_kin_delta as inverse
from bottle import run, request, get
import math

global cur_coords


def dist(v1, v2):
    return math.sqrt(
        (v1[0]-float(v2[0]))**2 +
        (v1[1]-float(v2[1]))**2 +
        (v1[2]-float(v2[2]))**2
    )


@get('/serialRelay')
def serial_queue():
    global cur_coords
    try:
        req_obj = json.loads(request.body.read())
        print(req_obj)
        for coords in req_obj:
            if coords[0] == "C":
                d = dist(cur_coords, coords[1:])
                d = d if d > 0 else 1
                dx = (float(coords[1]) - cur_coords[0]) / d
                dy = (float(coords[2]) - cur_coords[1]) / d
                dz = (float(coords[3]) - cur_coords[2]) / d
                for x in range(1, int(d), 1):
                    # print(
                    #     str(cur_coords[0]+x*dx),
                    #     str(cur_coords[1]+x*dy),
                    #     str(cur_coords[2]+x*dz)
                    #     )
                    angles = inverse(
                        float(cur_coords[0]+x*dx),
                        float(cur_coords[1]+x*dy),
                        float(cur_coords[2]+x*dz)
                        )
                    angles.append(int(coords[4]))
                    p_in.send(angles)

                angles = inverse(
                    float(coords[1]),
                    float(coords[2]),
                    float(coords[3])
                    )

                cur_coords[0] = float(coords[1])
                cur_coords[1] = float(coords[2])
                cur_coords[2] = float(coords[3])
                cur_coords[3] = float(coords[4])
                angles.append(int(coords[4]))
                p_in.send(angles)
                print(angles)

            if coords[0] == "A":
                Xc = float(coords[1])  # Xc
                Yc = float(coords[2])  # Yc
                Xr = float(coords[3])  # Xr
                Yr = float(coords[4])  # Yr
                Z = float(coords[5])  # Z
                A = float(coords[6])/180*math.pi  # A
                d = dist(
                    [coords[1], coords[2], coords[5]],
                    coords[3:6]
                    )*2*abs(A)
                dA = A/d
                X1 = 0
                Y1 = 0
                Z1 = 0
                for x in range(1, int(d), 1):
                    X1 = (Xr - Xc) * math.cos(dA*x) - (Yr - Yc) * math.sin(dA*x) + Xc
                    Y1 = (Xr - Xc) * math.sin(dA*x) + (Yr - Yc) * math.cos(dA*x) + Yc
                    Z1 = Z

                    angles = inverse(
                        X1,
                        Y1,
                        Z1
                    )
                    print(angles[0], angles[1], angles[2])
                    angles.append(int(coords[7]))
                    p_in.send(angles)
                cur_coords[0] = X1
                cur_coords[1] = Y1
                cur_coords[2] = Z1
                cur_coords[3] = int(coords[7])

        return 'Mission Success'
    except(json.JSONDecodeError):
        return 'Failed'


def serial_sender(pipe):
    p_out, p_in = pipe
    ready = True
    ser = serial.Serial('/dev/ttyUSB0', 115200)
    while True:
        if ready:
            try:
                angle = p_out.recv()
                # print('angle received')
                # print(angle)
                ser.write(struct.pack(
                    '<HHHc',
                    angle[0],
                    angle[1],
                    angle[2],
                    angle[3].to_bytes(1, byteorder="little")
                ))
                ready = False
            except(IndexError):
                pass

        if ser.in_waiting > 0:
            msg = ser.readline().decode("utf-8")
            if msg.strip() == "Ok":
                ready = True
            # print(msg)


p_out, p_in = Pipe(True)
cur_coords = [0, 0, 72, 50]
s_sender = Process(target=serial_sender, args=((p_out, p_in),))
s_sender.daemon = 'True'
s_sender.start()
run(host='localhost', port=8080, debug=True)
