import numpy as npy
import math


def inverse_kin_delta(x, y, z):
    L = 100  # dlugosc gornego ramienia

    l = 180  # dlugosc dolnego ramienia

    wb = 90  # odleglosc od srodka bazy do krawedzi, R na rysunkach

    up = 25  # odlegosc od srodka efektora do przegubu, r na rysunkach

    ub = 2*wb  # odlegosc od srodka bazy do przegubu, 2R

    wp = up/2  # odleglosc od srodka efektora do linii między przegubami, r/2

    sp = math.sqrt(3)*up  # dlugosc boku efektora

    angllimit = -110/180*math.pi
    anghlimit = 0

    a = wb - up
    b = sp/2 - math.sqrt(3)/2*wb
    c = wp - wb/2

    F = 2*z*L
    G = x**2 + y**2 + z**2 + L**2 - l**2  # uniwersalna czesc z G

    E1 = 2*L*(y+a)
    G1 = G + a**2 + 2*y*a

    E2 = -L * (math.sqrt(3)*(x + b) + y + c)
    G2 = G + b**2 + c**2 + 2*(x*b + y*c)

    E3 = L * (math.sqrt(3)*(x - b) - y - c)
    G3 = G + b**2 + c**2 + 2*(-x*b + y*c)

    t1 = npy.roots([G1-E1, 2*F, G1+E1])
    t2 = npy.roots([G2-E2, 2*F, G2+E2])
    t3 = npy.roots([G3-E3, 2*F, G3+E3])

    th11 = 2 * math.atan(t1[0])
    th21 = 2 * math.atan(t2[0])
    th31 = 2 * math.atan(t3[0])
    th12 = 2 * math.atan(t1[1])
    th22 = 2 * math.atan(t2[1])
    th32 = 2 * math.atan(t3[1])

    if th11 > th12 and th11 > angllimit and th11 < anghlimit:
        th1 = th11
    else:
        th1 = th12

    if th1 <= angllimit:
        th1 = angllimit
    elif th1 >= anghlimit:
        th1 = anghlimit

    if th21 > th22 and th21 > angllimit and th21 < anghlimit:
        th2 = th21
    else:
        th2 = th22

    if th2 <= angllimit:
        th2 = angllimit
    elif th2 >= anghlimit:
        th2 = anghlimit

    if th31 > th32 and th31 > angllimit and th31 < anghlimit:
        th3 = th31
    else:
        th3 = th32

    if th3 <= angllimit:
        th3 = angllimit
    elif th3 >= anghlimit:
        th3 = anghlimit

    # print("th11: %f", th11*180/math.pi)
    # print("th11: %f", th12*180/math.pi)

    # print("th21: %f", th21*180/math.pi)
    # print("th22: %f", th22*180/math.pi)

    # print("th31: %f", th31*180/math.pi)
    # print("th32: %f", th32*180/math.pi)
    # print("th1: ", int(th1*180/math.pi))
    # print("th1: ", int(th2*180/math.pi))
    # print("th1: ", int(th3*180/math.pi))

    return [int(th1*8000/math.pi)*-1, int(th2*8000/math.pi)*-1, int(th3*8000/math.pi)*-1]
