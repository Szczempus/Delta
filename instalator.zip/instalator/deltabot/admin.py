from django.contrib import admin

# Register your models here.

from .models import ChangesHistory, CommandHistory, SavedProgram
admin.site.register(ChangesHistory)
admin.site.register(CommandHistory)
admin.site.register(SavedProgram)
