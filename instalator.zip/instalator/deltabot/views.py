from django.shortcuts import get_object_or_404
from django.http import HttpResponse, JsonResponse
from django.views import generic
from .models import SavedProgram, CommandHistory, ChangesHistory
from django.utils import timezone
import http.client
import json
# Create your views here.


class IndexView(generic.ListView):
    template_name = 'deltabot/index.html'
    context_object_name = "saved_programs_list"

    def get_queryset(self):
        program_list = {
            'editables': SavedProgram.objects.filter(editable=True),
            'deletables': SavedProgram.objects.filter(deletable=True),
            'loadables': SavedProgram.objects.all()}
        return program_list


def serialRelay(request):
    c = http.client.HTTPConnection('localhost', 8080)
    c.request('GET', '/serialRelay', request.body)
    command = CommandHistory.objects.create(
        command_date=timezone.now(),
        command_type="CORD",
        prog_content=json.loads(request.body),
        )
    command.save()
    return HttpResponse("ok")


def updateProgram(request):
    req_obj = json.loads(request.body)
    program = get_object_or_404(SavedProgram, pk=req_obj['prog_id'])
    program.program_content = req_obj['prog_content']
    program.save()
    event = ChangesHistory.objects.create(
        event_date=timezone.now(),
        prog_id=program,
        event_type='EDT',
        )
    event.save()
    return HttpResponse("ok")


def deleteProgram(request):
    req_obj = json.loads(request.body)
    program = get_object_or_404(SavedProgram, pk=req_obj['prog_id'])
    name = program.program_name
    change_mention = ChangesHistory.objects.filter(prog_id__pk=req_obj['prog_id'])
    change_mention.update(prog_name=name)
    history_mention = CommandHistory.objects.filter(prog_id__pk=req_obj['prog_id'])
    history_mention.update(prog_name=name)
    event = ChangesHistory.objects.create(
        event_date=timezone.now(),
        event_type='DEL',
        prog_name=name,
        )
    program.delete()
    event.save()
    return HttpResponse("ok")


def addProgram(request):
    req_obj = json.loads(request.body)
    program = SavedProgram.objects.create(
        program_name=req_obj["prog_name"],
        added_date=timezone.now(),
        program_content=req_obj['prog_content'],
        deletable=req_obj["del"],
        editable=req_obj["edt"],
        )
    program.save()
    event = ChangesHistory.objects.create(
        event_date=timezone.now(),
        prog_id=program,
        event_type='ADD',
        )
    event.save()
    return HttpResponse("ok")


def loadProgram(request):
    req_obj = json.loads(request.body)
    program = get_object_or_404(SavedProgram, pk=req_obj['prog_id'])
    jason = program.program_content
    event = ChangesHistory.objects.create(
        event_date=timezone.now(),
        prog_id=program,
        event_type='LOD',
        )
    event.save()
    return JsonResponse(jason, safe=False)


def runProgram(request):
    req_obj = json.loads(request.body)
    program = get_object_or_404(SavedProgram, pk=req_obj['prog_id'])
    jason = program.program_content
    c = http.client.HTTPConnection('localhost', 8080)
    c.request('GET', '/serialRelay', json.dumps(jason))

    command = CommandHistory.objects.create(
        command_date=timezone.now(),
        command_type="PROG",
        prog_id=program,
        )
    command.save()
    return HttpResponse("ok")