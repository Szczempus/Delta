from django.apps import AppConfig


class DeltabotConfig(AppConfig):
    name = 'deltabot'
