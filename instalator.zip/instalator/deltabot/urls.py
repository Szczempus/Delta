from django.urls import path

from . import views

app_name = 'deltabot'
urlpatterns = [
    path('', views.IndexView.as_view(), name='index'),
    path('serialRelay', views.serialRelay, name='serialRelay'),
    path('updateProgram', views.updateProgram, name='updateProgram'),
    path('deleteProgram', views.deleteProgram, name='deleteProgram'),
    path('addProgram', views.addProgram, name='addProgram'),
    path('loadProgram', views.loadProgram, name='loadProgram'),
    path('runProgram', views.runProgram, name='runProgram'),
]
