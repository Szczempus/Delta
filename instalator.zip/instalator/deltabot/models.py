from django.db import models

# Create your models here.


class SavedProgram(models.Model):
    program_name = models.CharField(max_length=200)
    added_date = models.DateTimeField('date_added')
    deletable = models.BooleanField(default=True)
    editable = models.BooleanField(default=True)
    program_content = models.JSONField()

    def __str__(self):
        return self.program_name

    def is_deletable(self):
        return self.deletable

    def is_editable(self):
        return self.editable


class ChangesHistory(models.Model):
    event_date = models.DateTimeField('event_date')
    prog_id = models.ForeignKey(
        SavedProgram,
        on_delete=models.SET_NULL,
        null=True,
    )
    prog_name = models.CharField(
        max_length=200,
        null=True,
    )
    EVENT_TYPE_CHOICES = [
        ('ADD', 'Added'),
        ('EDT', 'Edited'),
        ('DEL', 'Deleted'),
        ('LOD', 'Loaded')
    ]
    event_type = models.CharField(
        choices=EVENT_TYPE_CHOICES,
        max_length=3,
    )

    def __str__(self):
        return self.event_date.strftime("%d-%B-%Y %H:%M:%S") + ' - ' + self.event_type


class CommandHistory(models.Model):
    command_date = models.DateTimeField('event_date')
    COMMAND_TYPES = [
        ('CORD', 'Coordinate'),
        ('PROG', 'Program')
    ]
    command_type = models.CharField(
        choices=COMMAND_TYPES,
        max_length=4,
    )
    prog_id = models.ForeignKey(
        SavedProgram,
        on_delete=models.SET_NULL,
        null=True,
    )
    prog_name = models.CharField(
        max_length=200,
        null=True,
    )
    prog_content = models.JSONField(null=True)
