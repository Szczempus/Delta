#!/bin/sh
sudo apt-get update
sudo apt-get --assume-yes install python3
sudo apt-get --assume-yes install python3-pip
sudo apt-get --assume-yes install python3-numpy
sudo apt-get --assume-yes install python3-django
cd ~
mkdir Projekt_Delta
cd Projekt_Delta

pip3 install bottle
pip3 install pyserial

django-admin.py startproject Projekt_Delta_Django .
python3 manage.py startapp deltabot
cp ~/inverse_kin_delta.py ./inverse_kin_delta.py
cp ~/serial_bridge.py ./serial_bridge.py

cd deltabot
rm -r *
cp -a ~/deltabot/. ./
cd ..
rm ./Projekt_Delta_Django/urls.py
cp ~/urls.py ./Projekt_Delta_Django/urls.py