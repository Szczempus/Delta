#!/bin/sh
cd ./Projekt_Delta
python3 manage.py runserver 0.0.0.0:8000 & python3 serial_bridge.py